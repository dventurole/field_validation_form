﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using static System.Collections.Specialized.BitVector32;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml;

namespace simulation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();


            btn_ValCity.Enabled = false;
            btn_ValAge.Enabled = false;
        }

        //path to file
        string dir = @".\files\";
        string path = "UserInfo.txt";
        string path2 = "user.xml";
        public User userCheck = new User();
        private void btn_ValName_Click(object sender, EventArgs e)
        {
            userCheck.Name = txt_name.Text;
            try
            {
                Regex rgxName = new Regex(@"^[a-zA-Z]{2}([a-zA-Z\s]){0,48}$");
                
                if (!rgxName.IsMatch(txt_name.Text))
                {
                    MessageBox.Show("Enter (1) a valid name! \n 2 up to 50 characters.");
                }
                else
                {
                    MessageBox.Show(txt_name.Text + " is a valid name.");
                    btn_ValName.Enabled = false;
                    btn_ValCity.Enabled = true;
                    txt_city.Focus();
                    userCheck.chkName = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show(txt_name.Text + MessageBoxButtons.OK).ToString();
                txt_name.Clear();
                txt_name.Focus();
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to quit the application?", "Exit?", MessageBoxButtons.YesNo).ToString() == "Yes")
            {
                this.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists(dir) == false)
            {
                Directory.CreateDirectory(dir);
            }
        }

        private void btn_ValCity_Click(object sender, EventArgs e)
        {
            userCheck.City = txt_city.Text;
            try
            {
                Regex rgxCity = new Regex(@"^((Montreal)|(Toronto)|(Ottawa))$");

                if (!rgxCity.IsMatch(txt_city.Text))
                {
                    MessageBox.Show("Enter (2) a valid city! \n Montreal, Ottawa or Toronto.");
                }
                else
                {
                    MessageBox.Show(txt_city.Text + " is a valid city.");
                    btn_ValName.Enabled = false;
                    btn_ValCity.Enabled = false;
                    btn_ValAge.Enabled = true;
                    txt_age.Focus();
                    userCheck.chkCity = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show(txt_city.Text + MessageBoxButtons.OK).ToString();
                txt_city.Clear();
                txt_city.Focus();
            }
        }

        private void btn_ValAge_Click(object sender, EventArgs e)
        {
            userCheck.Age = Convert.ToDouble(txt_age.Text);
            try
            {
                Regex rgxAge = new Regex(@"[0-9]{2}$");

                if (!rgxAge.IsMatch(txt_age.Text.ToString()) && Convert.ToInt32(txt_age.Text) < 18 &&
                    Convert.ToInt32(txt_age.Text) > 65)
                {
                    MessageBox.Show("Enter (3) a valid number! \n Should be between 18 and 65.");
                }
                else
                {
                    MessageBox.Show(txt_age.Text + " is a valid age.");
                    btn_ValName.Enabled = true;
                    btn_ValCity.Enabled = false;
                    btn_ValAge.Enabled = false;
                    txt_name.Focus();
                    userCheck.chkAge = true;
                }
            }
            catch (Exception)
            {
                MessageBox.Show(txt_age.Text + MessageBoxButtons.OK).ToString();
                txt_age.Clear();
                txt_age.Focus();
            }
        }

        private void btn_AppTxt_Click(object sender, EventArgs e)
        {
            if (userCheck.chkName == true && userCheck.chkCity == true && userCheck.chkAge == true)
            {
                //creates the file
                FileStream addInfo = new FileStream(dir + path, FileMode.Append, FileAccess.Write);
                StreamWriter writeInfo = new StreamWriter(addInfo);

                writeInfo.Write(txt_name.Text + "|" + txt_city.Text + "|" + txt_age.Text + "\n"); // print the data into the file
                writeInfo.Close(); // close the write stream for the text file
                addInfo.Close(); // close the FileStream

                txt_name.Clear();
                txt_city.Clear();
                txt_age.Clear();

                MessageBox.Show("The user was appended to the text file", "User Registered", MessageBoxButtons.OK);

            }
            else
            {
                MessageBox.Show("No input was added", "Error", MessageBoxButtons.OK);
            }
        }

        private void btn_Del_Click(object sender, EventArgs e)
        {
            if (File.Exists(dir + path) == true)
            {
                File.Delete(dir + path);
                MessageBox.Show("The file was deleted", "File Deleted", MessageBoxButtons.OK);
            }
        }

        private void btn_ReadTxt_Click(object sender, EventArgs e)
        {
            //prepares to read the file
            FileStream readFile = new FileStream(dir + path, FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader readInfo = new StreamReader(readFile);

            string display = "";
            string info = "";

            // create the XmlWriterSettings object
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true; settings.IndentChars = (" ");
            // create the XmlWriter object
            XmlWriter xmlOut = XmlWriter.Create(path2, settings);
            // write the start of the document
            xmlOut.WriteStartDocument();
            xmlOut.WriteStartElement("Users");

            while (readInfo.Peek() != -1) // read the file until there are no characters left
            {

                info = readInfo.ReadLine();
                display += info + "\n";

                // write username into the XML document
                {
                    xmlOut.WriteStartElement("User");
                    xmlOut.WriteElementString("Name", userCheck.Name);
                    xmlOut.WriteElementString("City", userCheck.City);
                    xmlOut.WriteElementString("Age", Convert.ToString(userCheck.Age));

                    // write the end tag for the root element
                    xmlOut.WriteEndElement();
                }
            }
            MessageBox.Show(display, "Reading");

            // write the end tag for the root element
            xmlOut.WriteEndElement();
            // close the XmlWriter object
            xmlOut.Close();

            readInfo.Close();
            readFile.Close();

        }

        private void btn_ReadXml_Click(object sender, EventArgs e)
        {
            // create the XmlReaderSettings object
            XmlReaderSettings settings = new XmlReaderSettings();
            settings.IgnoreWhitespace = true;
            settings.IgnoreComments = true;
            // create the XmlReader object
            XmlReader xmlIn = XmlReader.Create(path2, settings);
            string tempStr = "", name = "", city = "", age = "";
            // read past all nodes to the first UseName node
            if (xmlIn.ReadToDescendant("User")) // procura o elemento UserName para executar o loop
            {
                // create FN and LN string for each UseName node
                do
                {
                    xmlIn.ReadStartElement("User");
                    name = xmlIn.ReadElementContentAsString();
                    city = xmlIn.ReadElementContentAsString();
                    age = xmlIn.ReadElementContentAsString();
                    tempStr += name + ", " + city + ", " + age + "\n";
                }
                while (xmlIn.ReadToNextSibling("User")); // executa enquanto encontrar o elemento User
            }
            // close the XmlReader object
            xmlIn.Close();
            MessageBox.Show(tempStr);
        }
    }
    }
    public class User
    {
        // variables
        private string name, city;
        private double age;
        public bool chkName = false, chkCity = false, chkAge = false;

        // property
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public double Age
        {
            get { return age; }
            set { age = value; }
        }
    }

