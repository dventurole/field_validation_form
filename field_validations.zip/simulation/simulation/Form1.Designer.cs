﻿namespace simulation
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.btn_ValName = new System.Windows.Forms.Button();
            this.btn_ValCity = new System.Windows.Forms.Button();
            this.txt_city = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_ValAge = new System.Windows.Forms.Button();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_AppTxt = new System.Windows.Forms.Button();
            this.btn_ReadTxt = new System.Windows.Forms.Button();
            this.btn_ReadXml = new System.Windows.Forms.Button();
            this.btn_Del = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Full Name:";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(137, 51);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(276, 26);
            this.txt_name.TabIndex = 1;
            // 
            // btn_ValName
            // 
            this.btn_ValName.Location = new System.Drawing.Point(469, 48);
            this.btn_ValName.Name = "btn_ValName";
            this.btn_ValName.Size = new System.Drawing.Size(124, 33);
            this.btn_ValName.TabIndex = 2;
            this.btn_ValName.Text = "Validate";
            this.btn_ValName.UseVisualStyleBackColor = true;
            this.btn_ValName.Click += new System.EventHandler(this.btn_ValName_Click);
            // 
            // btn_ValCity
            // 
            this.btn_ValCity.Location = new System.Drawing.Point(469, 93);
            this.btn_ValCity.Name = "btn_ValCity";
            this.btn_ValCity.Size = new System.Drawing.Size(124, 33);
            this.btn_ValCity.TabIndex = 5;
            this.btn_ValCity.Text = "Validate";
            this.btn_ValCity.UseVisualStyleBackColor = true;
            this.btn_ValCity.Click += new System.EventHandler(this.btn_ValCity_Click);
            // 
            // txt_city
            // 
            this.txt_city.Location = new System.Drawing.Point(137, 96);
            this.txt_city.Name = "txt_city";
            this.txt_city.Size = new System.Drawing.Size(276, 26);
            this.txt_city.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "City:";
            // 
            // btn_ValAge
            // 
            this.btn_ValAge.Location = new System.Drawing.Point(469, 144);
            this.btn_ValAge.Name = "btn_ValAge";
            this.btn_ValAge.Size = new System.Drawing.Size(124, 33);
            this.btn_ValAge.TabIndex = 8;
            this.btn_ValAge.Text = "Validate";
            this.btn_ValAge.UseVisualStyleBackColor = true;
            this.btn_ValAge.Click += new System.EventHandler(this.btn_ValAge_Click);
            // 
            // txt_age
            // 
            this.txt_age.Location = new System.Drawing.Point(137, 147);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(276, 26);
            this.txt_age.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 150);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Age:";
            // 
            // btn_AppTxt
            // 
            this.btn_AppTxt.Location = new System.Drawing.Point(68, 203);
            this.btn_AppTxt.Name = "btn_AppTxt";
            this.btn_AppTxt.Size = new System.Drawing.Size(124, 67);
            this.btn_AppTxt.TabIndex = 9;
            this.btn_AppTxt.Text = "Append to txt file";
            this.btn_AppTxt.UseVisualStyleBackColor = true;
            this.btn_AppTxt.Click += new System.EventHandler(this.btn_AppTxt_Click);
            // 
            // btn_ReadTxt
            // 
            this.btn_ReadTxt.Location = new System.Drawing.Point(215, 203);
            this.btn_ReadTxt.Name = "btn_ReadTxt";
            this.btn_ReadTxt.Size = new System.Drawing.Size(124, 67);
            this.btn_ReadTxt.TabIndex = 10;
            this.btn_ReadTxt.Text = "Read txt Create xml";
            this.btn_ReadTxt.UseVisualStyleBackColor = true;
            this.btn_ReadTxt.Click += new System.EventHandler(this.btn_ReadTxt_Click);
            // 
            // btn_ReadXml
            // 
            this.btn_ReadXml.Location = new System.Drawing.Point(363, 203);
            this.btn_ReadXml.Name = "btn_ReadXml";
            this.btn_ReadXml.Size = new System.Drawing.Size(124, 67);
            this.btn_ReadXml.TabIndex = 11;
            this.btn_ReadXml.Text = "Read xml file";
            this.btn_ReadXml.UseVisualStyleBackColor = true;
            this.btn_ReadXml.Click += new System.EventHandler(this.btn_ReadXml_Click);
            // 
            // btn_Del
            // 
            this.btn_Del.Location = new System.Drawing.Point(215, 291);
            this.btn_Del.Name = "btn_Del";
            this.btn_Del.Size = new System.Drawing.Size(124, 69);
            this.btn_Del.TabIndex = 12;
            this.btn_Del.Text = "Delete txt file";
            this.btn_Del.UseVisualStyleBackColor = true;
            this.btn_Del.Click += new System.EventHandler(this.btn_Del_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(608, 383);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(124, 33);
            this.btn_Exit.TabIndex = 13;
            this.btn_Exit.Text = "E&xit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 431);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_Del);
            this.Controls.Add(this.btn_ReadXml);
            this.Controls.Add(this.btn_ReadTxt);
            this.Controls.Add(this.btn_AppTxt);
            this.Controls.Add(this.btn_ValAge);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_ValCity);
            this.Controls.Add(this.txt_city);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_ValName);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Prep for final";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_ValName;
        private System.Windows.Forms.Button btn_ValCity;
        private System.Windows.Forms.TextBox txt_city;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_ValAge;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_AppTxt;
        private System.Windows.Forms.Button btn_ReadTxt;
        private System.Windows.Forms.Button btn_ReadXml;
        private System.Windows.Forms.Button btn_Del;
        private System.Windows.Forms.Button btn_Exit;
    }
}

